# Challenge 4: Terraforming - Agent-based modelling

Welcome to this afternoon's challenge about Agent-based modelling.

There's no other files, just start a portal session with the 3.9.5 version of Python, open **Challenge_4.ipynb** from the challenge_4_participant_info directory and begin working through it.

Exercises 1-4 must be completed this afternoon. Before the end of the session, copy the version of the notebook you want to be marked into the **results** directory.

Exercises 5,6 and 7 must be completed before 9am tomorrow. These are bonus exercises. Feel to attempt them in the session if you have time.

To submit these exercises, copy the version of the notebook you want to be marked into **results_bonus**.

Please use a filename of the form for both submissions **team_{team_number}_challenge_4.ipynb**

My advice would be to study the notebook, then split into three groups,

+ One group works on exercises 1-3
+ One group looks at exercise 4
+ One group looks at the remaining text-based exercises

Remember that to get plotting to properly work in a jupyter notebook, put **%matplotlib inline** in a cell before you try plotting. You'll need this for exercise 4.

Good luck!
