#!/bin/bash

#SBATCH --qos=bham

#SBATCH --account=edmondac-bc23-team6

#SBATCH --reservation=edmondac-bc23-team6

#SBATCH --time=08:00:00

#SBATCH --gres=gpu:4

#SBATCH --nodes 1

module purge

module load baskdefault

while read -r line

do

./md5_gpu --charset=1 --hash="$line"

done < "./secrets3.txt"
